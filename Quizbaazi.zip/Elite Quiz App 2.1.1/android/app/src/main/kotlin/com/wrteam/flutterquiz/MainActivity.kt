package com.quizbaazi.flutterquiz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
