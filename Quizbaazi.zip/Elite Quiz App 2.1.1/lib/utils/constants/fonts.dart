import 'package:flutter/material.dart';

class FontWeights {
  static const regular = FontWeight.w400;
  static const medium = FontWeight.w500;
  static const semiBold = FontWeight.w600;
  static const bold = FontWeight.w700;
}

// class FontSizes {
// static const scale;
//   static const s10 = 10.0;
//   static const s12 = 12.0;
//   static const s14 = 14.0;
//   static const s16 = 16.0;
//   static const s18 = 18.0;
//   static const s20 = 20.0;
//   static const s22 = 22.0;
// }
